package daos;

import entities.IfscCodes;
import exceptions.CustException;

public interface IfscDao {
	void addBranch(IfscCodes ifsc)throws CustException;
	String getIfsc(String branch)throws CustException;
}
