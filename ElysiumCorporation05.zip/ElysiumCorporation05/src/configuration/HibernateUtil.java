package configuration;
import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.*;

public class HibernateUtil {

	private static SessionFactory factory = build();
	
	private static SessionFactory build() {
		try {
			Configuration conf = new Configuration().configure("hibernate.cfg.xml");
			StandardServiceRegistryBuilder builder = new  StandardServiceRegistryBuilder().configure("hibernate.cfg.xml");
			SessionFactory factory = conf.buildSessionFactory(builder.build());
			System.out.println("Connected");
			return factory;
		}
			catch(HibernateException e){
				System.out.println("error : "+e);
				return null;
			}
		} // singleton design pattern, only one object of build is created only once and it can be used everywhere even outside the project. 
	public static SessionFactory getFactory()
	{
		return factory;
	}
	}

