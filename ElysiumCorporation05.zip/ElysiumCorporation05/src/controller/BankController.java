/*
 * RESTController for managing requests from Front-End
 */
package controller;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


import entities.AccountDetails;
import entities.AuthenticationDetails;
import entities.BeneficiaryDetails;
import entities.CustomerAddress;
import entities.CustomerDetails;
import entities.TransactionDetails;
import exceptions.CustException;
import services.Services;


@EnableWebMvc
@RestController
public class BankController {
	
	@Autowired
	Services services;
	static Integer custId = null;
	
	/*
	 * Mapping to get the account summary
	 */
	@RequestMapping(value ="/accountSummary/{accType}",method = RequestMethod.GET, headers="Accept=application/json")
	public List<String> summary(@PathVariable String accType, Model model) throws CustException {
		
		List<String> strings=null;
		System.out.println("In controller"+accType);
		System.out.println("In controller"+custId);
		List<Object> summ = services.summary(custId, accType);
		if(summ==null)
		{
			strings = null;
		}
		else
		{
		strings = new ArrayList<>(summ.size());
		for (Object object : summ) {
		    strings.add(Objects.toString(object, null));
		}
		
		}
		return strings;
	}
	
	/*
	 * Mapping for openning of new bank account
	 */
	@RequestMapping(value = "/openAcc/{name}/{email}/{phno}/{dob}/{gen}/{branch}/{line1}/{line2}/{city}/{state}/{zip}/{country}/{aadhar}/{pan}/{accType}",
			 method = RequestMethod.POST)
	public Integer openAcc(@PathVariable String name,@PathVariable String email, 
			@PathVariable String phno, @PathVariable String dob, @PathVariable String gen, 
			@PathVariable String branch, @PathVariable String line1, @PathVariable String line2,
			@PathVariable String city, 
			@PathVariable String state, @PathVariable String zip, @PathVariable String country, 
			@PathVariable String aadhar, @PathVariable String pan, @PathVariable String accType) throws CustException
	{
		System.out.println("in open account");
		AccountDetails acc=new AccountDetails();
		CustomerDetails sd = new CustomerDetails();
		CustomerAddress ca = new CustomerAddress();
		sd.setAadharNo(aadhar);
		sd.setCustNme(name);
		sd.setMobileNo(phno);
		sd.setGender(gen);
		sd.setPanNo(pan);
		sd.setEmailId(email);
		
		Integer customerId = services.addCust(sd);
		
		String ifsc = services.getIfsc(branch);
		acc.setAccOpeningDate(new Date());
		acc.setAccType("Current");
		acc.setBalance(100000f);
		acc.setBranch(branch);
		acc.setCustId(customerId);
		acc.setIfsc(ifsc);
		Integer accNo = services.addAcc(acc);
		
		ca.setCity(city);
		ca.setCountry(country);
		ca.setCustId(customerId);
		ca.setLine1(line1);
		ca.setLine2(line2);
		ca.setPincode(zip);
		ca.setState(state);
		services.addAddress(ca);
		
		return accNo;
	}
	
	/*
	 * Mapping to register for online banking
	 */
	@RequestMapping(value="/register/{accno}/{mobno}/{email}/{pwd}",method=RequestMethod.POST, headers="Accept=application/json") 
    public void addUser(@PathVariable("accno") String accNo,@PathVariable("mobno") String mobNo,@PathVariable("email") String email,@PathVariable("pwd") String password) throws CustException {
		System.out.println("in register");
		
		Integer custId1=services.getCustomer(email);
		
     	AuthenticationDetails authDet = new AuthenticationDetails();
     	authDet.setCustId(custId1);
     	authDet.setAccNo(Integer.parseInt(accNo));
     	authDet.setMobileNo(mobNo);
     	authDet.setEmailId(email);
        authDet.setPassword(password);
        System.out.println(authDet);
        services.registerUser(authDet);
        
    }
	
	/*
	 * Mapping to add new beneficiary
	 */
    @RequestMapping(value="/addBeneficiary/{name}/{accno}/{bank}/{acctype}/{ifsc}",method=RequestMethod.POST)
    public void addBeneficiary(@PathVariable("name") String bname,@PathVariable("accno") String baccNo,@PathVariable("bank") String bbank,@PathVariable("acctype") String baccType,@PathVariable("ifsc") String bifsc) throws CustException
    {
    	
    System.out.println("in addben system");
    
     BeneficiaryDetails ben = new BeneficiaryDetails();
     ben.setCustId(custId);
     ben.setBenName(bname);
     ben.setBenBank(bbank);
     ben.setBenAccType(baccType);
     ben.setBenAccNo(Integer.parseInt(baccNo));
     ben.setBenIfsc(bifsc);
     services.addBeneficiary(ben);
    
    }
    /*
     * Mapping to get the list of beneficiaries related to the logged in customer
     */
    @RequestMapping(value ="/showBen",method = RequestMethod.GET)
	public List<BeneficiaryDetails> beneficiaries(Model model) throws CustException {
		
		System.out.println("In controller");
		List<BeneficiaryDetails> ben = services.showBeneficiaries(custId);
		System.out.println(ben);
		return ben;
	}
    /*
     * Mapping to delete a beneficiary	
     */
    @RequestMapping(value="/delBeneficiary/{benAccno}",method=RequestMethod.DELETE)
    public Integer removeBeneficiary(@PathVariable("benAccno") String baccNo) throws CustException
    {
    	if(services.deleteBeneficiary(baccNo) != null) {
    		return 1;
    	}else{
    		return 0;
    	}
    	
    }
    /*
     * Mapping for Infra Bank Transaction
     */
    @RequestMapping(value ="/intraTransfer/{accType}/{benAccNo}/{amount}/{benName}/{benBank}",method = RequestMethod.POST ,headers="Accept=application/json")
    public Integer intraBankTrans(@PathVariable String accType, @PathVariable Integer benAccNo, @PathVariable Float amount,@PathVariable String benName,@PathVariable String benBank) throws CustException {
    	
    	Integer accNo = services.getAcc(custId, accType);
	    TransactionDetails txn = new TransactionDetails();
	    txn.setAccNo(accNo);
	    txn.setPayeeAccNo(benAccNo);
	    txn.setCustId(custId);
	    txn.setAmount(amount);
	    txn.setTransferDate(new Date());
	    txn.setPayeeName(benName);
	    txn.setPayeeBank(benBank);
	    if(services.validateTrans(custId, benName, benBank, benAccNo))
	    {
	    	if(services.validAmount(accNo,amount))
	    	{
	    	services.intraBankTrans(accNo, benAccNo, amount, custId,txn);
	    		return 2;
	    	}
	    	else
	    	{
	    		return 1;
	    	}
	    }
	    else
	    {
	    	System.out.println("beneficiary doesnt exist");
	    	return 0;
	    }
   }
   /*
    * Mapping for Inter Bank Transaction
    */
   @RequestMapping(value ="/interTransfer/{accType}/{benAccNo}/{amount}/{benName}/{benBank}",method = RequestMethod.POST ,headers="Accept=application/json")
    public Integer interBankTrans(@PathVariable String accType, @PathVariable Integer benAccNo, @PathVariable Float amount,@PathVariable String benName,@PathVariable String benBank) throws CustException {
    
	    Integer accNo = services.getAcc(custId, accType);
	    TransactionDetails txn = new TransactionDetails();
	    txn.setAccNo(accNo);
	    txn.setPayeeAccNo(benAccNo);
	    txn.setCustId(custId);
	    txn.setAmount(amount);
	    txn.setTransferDate(new Date());
	    txn.setPayeeName(benName);
	    txn.setPayeeBank(benBank);
	    if(services.validateTrans(custId, benName, benBank, benAccNo))
	    { 
	    	if(services.validAmount(accNo,amount))
	    	{
	    	services.intraBankTrans(accNo, benAccNo, amount, custId,txn);
	    		return 2;
	    	}
	    	else
	    	{
	    		return 1;
	    	}
	    }
	    else
	    {
	    	System.out.println("beneficiary doesnt exist");
	    	return 0;
	    }
   }
   /*
    * Mapping to authenticate login	
    */
   @RequestMapping(value ="/authenticate/{username}/{password}",method = RequestMethod.POST)
   public Integer authenticate(@PathVariable String username, @PathVariable String password) throws CustException, IOException {
	   
   custId=services.getCustId(username);
   
   if(custId==null) {
	   System.out.println("user doesnt exist");
	   return 0;
   }
   else {
	   List<String> idAndPass = services.getIdPass(custId);
	   System.out.println(idAndPass.get(1));
	   if(idAndPass.get(1).equals(password)) {
		   System.out.println("successful login");
		  System.out.println(custId);
		   return 2;
	   }
	   else {
		   System.out.println("username or password doesnt match");
		   return 1;
	   }
   }
  }
	/*
	 * Mapping to fetch customer details
	 */
	 @RequestMapping(value ="/profile",method = RequestMethod.GET)
		public CustomerDetails custProfile(Model model) throws CustException {
			
			System.out.println("In controller"+custId);
			CustomerDetails det = services.getCust(custId);
			
			System.out.println(det);
			return det;
		}
	 /*
	  * mapping to get e-statement by date and generate pdf
	  */
	 @RequestMapping(value ="/accountStatementByDate/{date1}/{date2}",method = RequestMethod.GET)
		public List<TransactionDetails> statementByDate(Model model,@PathVariable Date date1,@PathVariable Date date2) throws CustException {
			
			List<TransactionDetails> summ = services.statementForDates(custId, date1, date2);
			System.out.println(summ);
			
			return summ;
		}
		
		/*
		 * MApping to check user for customer
		 */
				@RequestMapping(value ="/checkUser/{accNo}/{email}",method = RequestMethod.POST)
		public Integer checkUser(@PathVariable Integer accNo, @PathVariable String email) throws CustException {
			//custId=1;
			Integer data = null;
			System.out.println("In controller"+custId);
			Integer custId1=services.getCustomer(email);
			List<String> idPass = services.getIdPass(custId1);
			if(custId1==null)
			{
				System.out.println("user not available");
				data = 0;
				
					
			}else
			{
				if(idPass.get(0).equals(email))
				{
					data =2;
				}
				else
				{
					data = 1;
					System.out.println("email not registered");
				}
			}
				
			
			//List<String> strings = new ArrayList<>(det.size());
			/*for (Object object : det) {
			    strings.add(Objects.toString(object, null));
			}*/
		
			return data;
		}

}
	
