package application;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



import daos.AccountDao;
import daos.CustomerDao;
import daos.TransactionDao;
import entities.AccountDetails;
import entities.AuthenticationDetails;
import entities.BeneficiaryDetails;
import entities.CustomerAddress;
import entities.CustomerDetails;
import entities.TransactionDetails;
import exceptions.CustException;
import implementations.AccountDaoImpl;
import implementations.CustomerDaoImpl;
import implementations.TransactionDaoImpl;
import services.Services;

public class Main {

	public static void main(String[] args) {
		String dob = "03/08/1996";
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;
		try {
			date = formatter.parse(dob);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*CustomerAddress addr = new CustomerAddress();
		addr.setCustId(1);
		addr.setLine1("226/5");
		addr.setLine2("lajpat nagar");
		addr.setCity("hisar");
		addr.setState("haryana");
		addr.setCountry("india");
		addr.setPincode("125001");
		CustomerDetails cust = new CustomerDetails();
		
		cust.setCustNme("Deep");
		cust.setMobileNo("9876543210");
		cust.setGender("male");
		cust.setEmailId("deep.malik@gmail.com");
		cust.setAadharNo("1123456789");
		cust.setPanNo("ADFS98DF");
		
		
		
		BeneficiaryDetails ac1 = new BeneficiaryDetails();
		ac1.setBeneficiary_account_no("0123078388");
		ac1.setBeneficiary_account_type("savings");
		ac1.setBeneficiary_bank("icici");
		ac1.setBeneficiary_ifsc("SB1234");
		ac1.setBeneficiary_name("jaadu");
		ac1.setCustId(1);
		*/
		
		/*List<BeneficiaryDetails> beneficiaries = null;
		beneficiaries = dao1.getBeneficiaries(1);
		for(BeneficiaryDetails ben:beneficiaries)
		{
			System.out.println(ben.getBeneficiary_name()+" "+ben.getBeneficiary_account_no());
		}*/
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Services services = (Services) ctx.getBean("Services");
		/*String str1 = "2018-02-01";
		String str2 = "2018-02-27";
		
		SimpleDateFormat dt = new SimpleDateFormat("dd-MMM-yyyy");
		String dateInString1 = "1-FEB-2018";
		String dateInString2 = "25-FEB-2018";
		
		Date date1 = null;
		Date date2 = null;
		try {
			
			 date1 = dt.parse(dateInString1);
			 date2 = dt.parse(dateInString2);
//			date1 = dt.parse(str1);
//			date2 = dt.parse(str2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		/*List<TransactionDetails> statement = services.statementForDates(1, date1, date2);
		for(TransactionDetails trans: statement)
		{
			System.out.println(trans);
		}
		
		//services.intraBankTrans(1234567892.0, 12301101.0, 20000f, 1);
		//services.deleteBeneficiary(benDetail);
		
		
		
	
	}*/
//		AccountDetails acc = new AccountDetails();
//		System.out.println(services.summary(1, "SAVINGS"));
	
		/*AuthenticationDetails ad = new AuthenticationDetails();
		ad.setAccNo(23);
		ad.setCustId(1);
		ad.setEmailId("abcd@gmail.com");
		ad.setMobileNo("9999999999");
		ad.setPassword("12345");
		services.registerUser(ad);*/
		
		//System.out.println(services.getIfsc("Pune"));
		
		/*try {
			
			System.out.println(services.summary(7,"Current"));
		} catch (CustException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		}*/
		}
		}
