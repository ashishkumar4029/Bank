/**
 * _refreshPageData() will call automatically when page loaded
 *  Calling _refreshPageData() after every add & Remove of data
 */

var myWebservice=angular.module("myApp",[]);

myWebservice.controller("ServiceController", function($scope, $http) {
	_refreshPageData();
	//Check url according to your Application name & PORT
	function _refreshPageData(){
$http({
	method: 'GET',
	url: 'http://localhost:8082/ElysiumCorporation03/rest/accountSummary.json'
		}).success(function(data)
			{
			alert('data received')
			$scope.posts = data; // response data 
			
			});
	}
$scope.accOpForm = {
		custNme ,
		emailId ,
		gender ,
		aadharNo ,
		panNo , 
		dateOfBirth , 
		mobileNo ,
		branch ,
		line1 ,
		line2 ,
		city ,
		state ,
		country ,
		pincode ,
		accType
	};

$scope.add=function(){
	//Check url according to your Application name & PORT/account/open/{name}/{email}/{phno}
	//{dob}/{gen}/{branch}/{line1}/{line2}/{city}
	//{state}/{zip}/{country}/{aadhar}/{pan}/{sign}/{photo}/{accType}"
	
	$http({
		method:'POST',
		url:'http://localhost:8081/SpringAngularHiber/rest/account/open/'+$scope.accOpForm.custNme+'/'+$scope.accOpForm.emailId+'/'+$scope.accOpForm.mobileNo+'/'+$scope.accOpForm.dateOfBirth+'/'+$scope.accOpForm.gender+'/'+$scope.accOpForm.branch+'/'+$scope.accOpForm.line1+'/'+$scope.accOpForm.line2+'/'+$scope.accOpForm.city+'/'+$scope.accOpForm.state+'/'+$scope.accOpForm.pincode+'/'+$scope.accOpForm.country+'/'+$scope.accOpForm.aadharNo+'/'+$scope.accOpForm.panNo+'/'+$scope.accOpForm.sign+'/'+$scope.accOpForm.photo+'/'+$scope.accOpForm.accType
	}).success(function(data)
			{
			alert("DATA ADDED");	
			_refreshPageData();
			});
	
}
/*$scope.remove=function(data){
	
	//Check url according to your Application name & PORT	
	$http({
		method:'DELETE',
		url:'http://localhost:8081/SpringAngularHiber/rest//countries/delete/'+data
	}).success(function(data)
			{
			alert('Data Deleted')	
			 _refreshPageData();
			
			});
	
}

$scope.getCountryMap=function(data){
	
	//Check url according to your Application name & PORT	
	$http({
		method:'GET',
		url:'http://localhost:8081/SpringWithAngular/rest//countries/map/'+data
	}).success(function(data)
			{
			$scope.map = "http://localhost:8081/SpringAngularHiber/images/"+data; // response data 
			});
	
}

	
		
	
	*/
});

