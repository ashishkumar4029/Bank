package daos;

import java.util.List;

import entities.AuthenticationDetails;
import exceptions.CustException;

public interface AuthenticationDao {
	void addUser(AuthenticationDetails auth) throws CustException;
	void changePassword(Integer custId, String newPass) throws CustException;
	List<String> getIdAndPass(Integer custId) throws CustException;
	Integer getCustId(String email) throws CustException;
}
