package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public class AuthenticationDetails {
	
	private Integer custId;
	
	
	private Integer accNo;
	
	
	private String mobileNo;
	
	
	private String emailId;
	
	
	private String password;
	
	public AuthenticationDetails() {
		super();
	}

	public AuthenticationDetails(Integer custId, Integer accNo, String mobileNo, String emailId, String password) {
		super();
		this.custId = custId;
		this.accNo = accNo;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.password = password;
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public Integer getAccNo() {
		return accNo;
	}

	public void setAccNo(Integer accNo) {
		this.accNo = accNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "AuthenticationDetails [custId=" + custId + ", accountNo=" + accNo + ", mobileNo=" + mobileNo
				+ ", emailId=" + emailId + ", password=" + password + "]";
	}


	
	
	
	
}