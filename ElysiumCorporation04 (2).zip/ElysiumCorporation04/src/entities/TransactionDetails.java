package entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction_details")
public class TransactionDetails {
	
	private Integer transId;
	
	
	private Integer custId;
	
	private Integer accNo;
	
	private Integer payeeAccNo;
	
	
	private String payeeName;
	
	
	private String payeeBank;
	
	private Date transferDate;
	
	private Float amount;
	
	private Float updatedBalance;

	public Float getUpdatedBalance() {
		return updatedBalance;
	}

	public void setUpdatedBalance(Float updatedBalance) {
		this.updatedBalance = updatedBalance;
	}

	public Float getAmount() {
		return amount;
	}
	
	public TransactionDetails()
	{
		super();
	}

	
	public TransactionDetails(Integer transId, Integer custId, Integer accNo, Integer payeeAccNo, String payeeName,
			String payeeBank, Date transferDate, Float amount, Float updatedBalance) {
		super();
		this.transId = transId;
		this.custId = custId;
		this.accNo = accNo;
		this.payeeAccNo = payeeAccNo;
		this.payeeName = payeeName;
		this.payeeBank = payeeBank;
		this.transferDate = transferDate;
		this.amount = amount;
		this.updatedBalance = updatedBalance;
	}

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public Integer getAccNo() {
		return accNo;
	}

	public void setAccNo(Integer accNo) {
		this.accNo = accNo;
	}

	public Integer getPayeeAccNo() {
		return payeeAccNo;
	}

	public void setPayeeAccNo(Integer benAccNo) {
		this.payeeAccNo = benAccNo;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public String getPayeeBank() {
		return payeeBank;
	}

	public void setPayeeBank(String payeeBank) {
		this.payeeBank = payeeBank;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "TransactionDetails [transId=" + transId + ", custId=" + custId + ", accNo=" + accNo + ", payeeAccNo="
				+ payeeAccNo + ", payeeName=" + payeeName + ", payeeBank=" + payeeBank + ", transferDate="
				+ transferDate + ", amount=" + amount + ", updatedBalance=" + updatedBalance + "]";
	}


	
}
