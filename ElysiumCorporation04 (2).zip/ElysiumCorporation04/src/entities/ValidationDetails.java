package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class ValidationDetails {

	
	private String aadharNo;
	
	
	private String panNo;
	
	
	private String status;
	
	private String custName;
	
	public ValidationDetails()
	{
		super();
	}

	public ValidationDetails(String aadharNo, String panNo, String status, String custName) {
		super();
		this.aadharNo = aadharNo;
		this.panNo = panNo;
		this.status = status;
		this.custName = custName;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@Override
	public String toString() {
		return "ValidationDetails [aadharNo=" + aadharNo + ", panNo=" + panNo + ", status=" + status + ", custName="
				+ custName + "]";
	}
	
	
	
	
}
