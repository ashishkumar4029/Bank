package implementations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import daos.AccountDao;
import daos.AddressDao;
import daos.AuthenticationDao;
import daos.BeneficiaryDao;
import daos.CustomerDao;
import daos.IfscDao;
import daos.TransactionDao;
import entities.AccountDetails;
import entities.AuthenticationDetails;
import entities.BeneficiaryDetails;
import entities.CustomerAddress;
import entities.CustomerDetails;
import entities.TransactionDetails;
import exceptions.CustException;
import services.Services;

@Service("Services")
public class ServicesImpl implements Services{

	
	@Autowired 
	private AccountDao ad ;
	@Autowired
	private TransactionDao txn;
	@Autowired 
	private AccountDao acd;
	@Autowired 
	private AddressDao add;
	@Autowired 
	private CustomerDao cd;
	@Autowired 
	private BeneficiaryDao ben;
	@Autowired 
	private IfscDao ifsc;
	@Autowired
	private AuthenticationDao aut;
	@Autowired
	private BeneficiaryDao bd;
	
	@Override
	public List<Object> summary(Integer custId, String accType) throws CustException {
		
		List<AccountDetails> accDetails=ad.showAccount(custId, accType);
		Integer accNo = accDetails.get(0).getAccNo();
		System.out.println(accNo); 
		String branch = accDetails.get(0).getBranch();
		Float balance = accDetails.get(0).getBalance();
		Float lastAmt = txn.getLastTransAmount(accNo);
		Date lastDate = txn.getLastTransDate(accNo);
		String ifsc = accDetails.get(0).getIfsc();
		List<Object> summary = new ArrayList<>();
		summary.add(accNo);
		summary.add(accType);
		summary.add(branch);
		summary.add(balance);
		summary.add(lastDate);
		summary.add(lastAmt);
		summary.add(ifsc);
		return summary;
	}
	
	@Override
	public void addBeneficiary(BeneficiaryDetails beneficiary)throws CustException {
		
		ben.addBeneficiary(beneficiary);
			
	}
	
	@Override
	public List<BeneficiaryDetails> showBeneficiaries(Integer custId)throws CustException{
		 
		return ben.getBeneficiaries(custId);
	 }
	
	@Override
		public void deleteBeneficiary(String benAccNo)throws CustException{

			ben.removeBeneficiary(benAccNo);
		}
	
	
	
	public Integer addCust(CustomerDetails c)throws CustException {
		return cd.addCustomer(c);
	}

	@Override
	public List<TransactionDetails> statementForMonth(Integer custId, Date date)throws CustException {
		
		return txn.detailByMonth(custId, date);
	}

	@Override
	public List<TransactionDetails> statementForSixMonth(Integer custId, Date date)throws CustException {
		
		return txn.detailBySixMonth(custId, date);
	}

	@Override
	public List<TransactionDetails> statementForDates(Integer custId, Date date1, Date date2)throws CustException {
		
		return txn.detailByDate(custId, date1, date2);
	}
	
	 @Override
	 public void interBankTrans(Integer accNo,Integer benAccNo,Float amount,Integer custId, TransactionDetails trans)throws CustException {
		 
		 acd.doDebit(amount,custId, accNo);
		 Float uBalance = acd.getAmount(accNo);
		 trans.setUpdatedBalance(uBalance);
		 txn.addTransaction(trans);
	 }
	 
	 @Override
	 public void intraBankTrans(Integer accNo, Integer benAccNo, Float amount, Integer custId, TransactionDetails trans)throws CustException {
		 
		 acd.doDebit(amount,custId, accNo);
		 acd.doCredit(amount,custId ,benAccNo);
		 Float uBalance = acd.getAmount(accNo);
		 trans.setUpdatedBalance(uBalance);
		 txn.addTransaction(trans);
	 }

	@Override
	public void addAddress(CustomerAddress a)throws CustException {
		add.addAddress(a);
	}

	@Override
	public Integer addAcc(AccountDetails acc)throws CustException {
		return ad.openAccount(acc);
	}
	
	public String getIfsc(String branch)throws CustException {
		return ifsc.getIfsc(branch);
	}

	@Override
	public void registerUser(AuthenticationDetails authDet)throws CustException{
		  aut.addUser(authDet);
		
	}

	@Override
	public Boolean validateTrans(Integer custId, String benName, String benBank, Integer benAccNo)throws CustException {
		return ben.validateBen(custId, benName, benBank, benAccNo);
	}

	@Override
	public Integer getAcc(Integer custId, String accType)throws CustException {
		Integer accNo = 0;
		List<AccountDetails> ad = acd.showAccount(custId);
		for(AccountDetails acc:ad)
		{
			accNo = acc.getAccNo();
		}
		return accNo;
	}

	@Override
	public Integer getCustId(String email)throws CustException {
		return aut.getCustId(email);
	}

	@Override
	public List<String> getIdPass(Integer custId)throws CustException {
		return aut.getIdAndPass(custId);
	}
	@Override
	public CustomerDetails getCust(Integer custId) throws CustException
	{
		return cd.getCustomer(custId);
	}
	
	@Override
	public Integer getCustomer(String email)throws CustException {
		return cd.getCustId(email);
	}

	@Override
	public boolean validAmount(Integer accNo, Float amount) {
		return acd.checkAmount(accNo,amount);
	}

	@Override
	public Integer checkBenAcc(Integer custId, String baccNo) throws CustException {
		return bd.getBenAcc(custId,baccNo);
		
	}
}
