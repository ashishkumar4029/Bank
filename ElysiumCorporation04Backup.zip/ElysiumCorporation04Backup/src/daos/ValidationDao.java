package daos;

import java.util.List;

import entities.ValidationDetails;
import exceptions.CustException;

public interface ValidationDao {
	void addDetails(ValidationDetails det)throws CustException;
	List<String> getNameAndPan(String aadhar)throws CustException;
	String isChecked(String aadhar)throws CustException;
	void updateCheck(String aadhar)throws CustException;
}
